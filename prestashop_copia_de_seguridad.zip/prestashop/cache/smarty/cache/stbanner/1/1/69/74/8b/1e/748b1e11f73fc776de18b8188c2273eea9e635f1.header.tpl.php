<?php /*%%SmartyHeaderCode:444198260615e186e76cf14-56404240%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '748b1e11f73fc776de18b8188c2273eea9e635f1' => 
    array (
      0 => 'C:\\laragon\\www\\prestashop_1.6.1.24\\prestashop\\modules\\stbanner\\views\\templates\\hook\\header.tpl',
      1 => 1633442186,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '444198260615e186e76cf14-56404240',
  'variables' => 
  array (
    'custom_css' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_615e186e785561_57415153',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_615e186e785561_57415153')) {function content_615e186e785561_57415153($_smarty_tpl) {?><?php }} ?>
