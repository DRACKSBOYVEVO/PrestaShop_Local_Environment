<?php /*%%SmartyHeaderCode:1671210119615e187011e9a2-10346336%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c6117e7da50bd5096e9d54b7e766a67513db4d8d' => 
    array (
      0 => 'C:\\laragon\\www\\prestashop_1.6.1.24\\prestashop\\themes\\transformer\\modules\\blockcategories\\blockcategories.tpl',
      1 => 1633442184,
      2 => 'file',
    ),
    '5843feb684a222e6ac464c656ac9071f5285865d' => 
    array (
      0 => 'C:\\laragon\\www\\prestashop_1.6.1.24\\prestashop\\themes\\transformer\\modules\\blockcategories\\category-tree-branch.tpl',
      1 => 1633442184,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1671210119615e187011e9a2-10346336',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_615e18b7a1c017_54295368',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_615e18b7a1c017_54295368')) {function content_615e18b7a1c017_54295368($_smarty_tpl) {?><!-- Block categories module -->
<div id="categories_block_left" class="block">
	<h2 class="title_block">
					Panties
			</h2>
	<div class="block_content categories_tree_block">
		<ul class="tree dhtml">
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/materiales-44" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Materiales
	</a>
			<ul>
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/algodon-45" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Algodón
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/microfibra-46" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Microfibra
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/encaje-47" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Encaje
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/blanda-48" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Blanda
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/tul-49" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Tul
	</a>
	</li>

									</ul>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/buscar-por-50" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Buscar por
	</a>
			<ul>
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/ver-todos-51" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Ver todos
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/los-mas-vendidos-52" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Los más vendidos
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/nuevos-panties-53" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Nuevos panties
	</a>
	</li>

									</ul>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/tipo-de-panties-54" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Tipo de panties
	</a>
			<ul>
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/clasicos-55" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Clásicos
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/panty-hipster-56" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Panty - Hipster
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/cachetero-57" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Cachetero
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/boxer-58" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Boxer
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/tanga-59" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Tanga
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/brasileras-e-hilos-60" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Brasileras E Hilos
	</a>
	</li>

									</ul>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/beneficios-61" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Beneficios
	</a>
			<ul>
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/corte-invisible-62" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Corte Invisible
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/control-y-reduccion-63" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Control Y Reducción
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/levanta-cola-64" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Levanta Cola
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/levanta-cola-65" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Levanta Cola
	</a>
	</li>

									</ul>
	</li>

									</ul>
	</div>
</div>
<!-- /Block categories module -->
<?php }} ?>
