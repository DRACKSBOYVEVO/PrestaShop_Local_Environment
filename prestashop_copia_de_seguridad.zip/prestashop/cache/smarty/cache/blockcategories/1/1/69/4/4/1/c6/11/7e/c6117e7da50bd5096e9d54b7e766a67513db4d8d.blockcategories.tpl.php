<?php /*%%SmartyHeaderCode:1671210119615e187011e9a2-10346336%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c6117e7da50bd5096e9d54b7e766a67513db4d8d' => 
    array (
      0 => 'C:\\laragon\\www\\prestashop_1.6.1.24\\prestashop\\themes\\transformer\\modules\\blockcategories\\blockcategories.tpl',
      1 => 1633442184,
      2 => 'file',
    ),
    '5843feb684a222e6ac464c656ac9071f5285865d' => 
    array (
      0 => 'C:\\laragon\\www\\prestashop_1.6.1.24\\prestashop\\themes\\transformer\\modules\\blockcategories\\category-tree-branch.tpl',
      1 => 1633442184,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1671210119615e187011e9a2-10346336',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_615f5291a139d4_73175337',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_615f5291a139d4_73175337')) {function content_615f5291a139d4_73175337($_smarty_tpl) {?><!-- Block categories module -->
<div id="categories_block_left" class="block">
	<h2 class="title_block">
					Tops
			</h2>
	<div class="block_content categories_tree_block">
		<ul class="tree dhtml">
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/camisetas-5" title="Los must have de tu armario; ¡échale un vistazo a los diferentes colores, 
 formas y estilos de nuestra colección!">
		<span>&raquo;&nbsp;&nbsp;</span>Camisetas
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/blusas-7" title="Combina tus blusas preferidas con los accesorios perfectos para un look deslumbrante.">
		<span>&raquo;&nbsp;&nbsp;</span>Blusas
	</a>
	</li>

									</ul>
	</div>
</div>
<!-- /Block categories module -->
<?php }} ?>
