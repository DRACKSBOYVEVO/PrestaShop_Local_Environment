<?php /*%%SmartyHeaderCode:1671210119615e187011e9a2-10346336%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c6117e7da50bd5096e9d54b7e766a67513db4d8d' => 
    array (
      0 => 'C:\\laragon\\www\\prestashop_1.6.1.24\\prestashop\\themes\\transformer\\modules\\blockcategories\\blockcategories.tpl',
      1 => 1633442184,
      2 => 'file',
    ),
    '5843feb684a222e6ac464c656ac9071f5285865d' => 
    array (
      0 => 'C:\\laragon\\www\\prestashop_1.6.1.24\\prestashop\\themes\\transformer\\modules\\blockcategories\\category-tree-branch.tpl',
      1 => 1633442184,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1671210119615e187011e9a2-10346336',
  'variables' => 
  array (
    'blockCategTree' => 0,
    'currentCategory' => 0,
    'isDhtml' => 0,
    'child' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_615e187017d440_75329590',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_615e187017d440_75329590')) {function content_615e187017d440_75329590($_smarty_tpl) {?><!-- Block categories module -->
<div id="categories_block_left" class="block">
	<h2 class="title_block">
					Categorías
			</h2>
	<div class="block_content categories_tree_block">
		<ul class="tree dhtml">
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/mujer-3" title="Aquí encontrarás todas las colecciones de moda de mujer.  
 Esta categoría incluye todos los básicos de tu armario y mucho más: 
 ¡zapatos, complementos, camisetas estampadas, vestidos muy femeninos y vaqueros para mujer!">
		<span>&raquo;&nbsp;&nbsp;</span>Mujer
	</a>
			<ul>
												
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/vestidos-8" title="¡Encuentra tus vestidos favoritos entre nuestra amplia colección de vestidos de noche, vestidos informales y vestidos veraniegos! 
 Te ofrecemos vestidos para todos los días, para cualquier estilo y cualquier ocasión.">
		<span>&raquo;&nbsp;&nbsp;</span>Vestidos
	</a>
			<ul>
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/vestidos-informales-9" title="¿Estás buscando un vestido para todos los días? Échale un vistazo a 
 nuestra selección para encontrar el vestido perfecto.">
		<span>&raquo;&nbsp;&nbsp;</span>Vestidos informales
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/vestidos-noche-10" title="¡Descubre nuestra colección y encuentra el vestido perfecto para una velada inolvidable!">
		<span>&raquo;&nbsp;&nbsp;</span>Vestidos de noche
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/vestidos-verano-11" title="Cortos, largos, de seda, estampados... aquí encontrarás el vestido perfecto para el verano.">
		<span>&raquo;&nbsp;&nbsp;</span>Vestidos de verano
	</a>
	</li>

									</ul>
	</li>

									</ul>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/ropa-interior-12" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Ropa interior
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/pijamas-13" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Pijamas
	</a>
			<ul>
												
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/buscar-por-19" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Buscar por
	</a>
			<ul>
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/nueva-coleccion-20" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Nueva colección
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/batolas-21" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Batolas
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/short-22" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Short
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/capri-23" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Capri
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/pantalon-largo-24" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Pantalón largo
	</a>
	</li>

									</ul>
	</li>

									</ul>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/sport-live-14" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Sport Live
	</a>
			<ul>
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/buscar-por-25" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Buscar por
	</a>
			<ul>
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/ver-todos-26" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Ver todos
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/tops-27" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Tops
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/camisillas-28" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Camisillas
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/camisetas-29" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Camisetas
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/chaqueta-30" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Chaqueta
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/short-31" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Short
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/capri-32" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Capri
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/leggins-33" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Leggins
	</a>
	</li>

									</ul>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/beneficios-34" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Beneficios
	</a>
			<ul>
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/control-de-abdomen-35" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Control de abdomen
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/ecoprocess-36" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Ecoprocess
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/secado-rapido-37" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Secado rápido
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/proteccion-solar-38" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Protección solar
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/ajuste-comodo-39" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Ajuste cómodo
	</a>
	</li>

									</ul>
	</li>

									</ul>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/nueva-coleccion-15" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Nueva Colección
	</a>
			<ul>
												
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/tops-4" title="Aquí encontrarás camisetas, tops, blusas, camisetas de manga corta, de manga larga, sin mangas, de media manga y mucho más. 
 ¡Encuentra el corte que mejor te quede!">
		<span>&raquo;&nbsp;&nbsp;</span>Tops
	</a>
			<ul>
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/camisetas-5" title="Los must have de tu armario; ¡échale un vistazo a los diferentes colores, 
 formas y estilos de nuestra colección!">
		<span>&raquo;&nbsp;&nbsp;</span>Camisetas
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/blusas-7" title="Combina tus blusas preferidas con los accesorios perfectos para un look deslumbrante.">
		<span>&raquo;&nbsp;&nbsp;</span>Blusas
	</a>
	</li>

									</ul>
	</li>

									</ul>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/outlet-16" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Outlet
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/venta-por-catalogo-17" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Venta por catálogo
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/buscar-por-18" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Buscar por
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/panties-40" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Panties
	</a>
			<ul>
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/materiales-44" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Materiales
	</a>
			<ul>
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/algodon-45" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Algodón
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/microfibra-46" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Microfibra
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/encaje-47" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Encaje
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/blanda-48" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Blanda
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/tul-49" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Tul
	</a>
	</li>

									</ul>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/buscar-por-50" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Buscar por
	</a>
			<ul>
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/ver-todos-51" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Ver todos
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/los-mas-vendidos-52" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Los más vendidos
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/nuevos-panties-53" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Nuevos panties
	</a>
	</li>

									</ul>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/tipo-de-panties-54" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Tipo de panties
	</a>
			<ul>
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/clasicos-55" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Clásicos
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/panty-hipster-56" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Panty - Hipster
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/cachetero-57" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Cachetero
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/boxer-58" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Boxer
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/tanga-59" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Tanga
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/brasileras-e-hilos-60" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Brasileras E Hilos
	</a>
	</li>

									</ul>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/beneficios-61" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Beneficios
	</a>
			<ul>
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/corte-invisible-62" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Corte Invisible
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/control-y-reduccion-63" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Control Y Reducción
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/levanta-cola-64" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Levanta Cola
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/levanta-cola-65" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Levanta Cola
	</a>
	</li>

									</ul>
	</li>

									</ul>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/brasieres-66" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Brasieres
	</a>
			<ul>
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/buscar-por-67" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Buscar por
	</a>
			<ul>
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/ver-todos-72" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Ver todos
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/los-mas-vendidos-73" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Los más vendidos
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/brasieres-nuevos-74" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Brasieres nuevos
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/bodies-75" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Bodies
	</a>
	</li>

									</ul>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/tipo-de-brasier-68" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Tipo de brasier
	</a>
			<ul>
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/bralettes-76" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Bralettes
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/strapless-77" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Strapless
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/con-varillas-78" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Con Varillas
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/sin-varillas-79" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Sin Varillas
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/escope-profundo-80" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Escope profundo
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/deportivo-81" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Deportivo
	</a>
	</li>

									</ul>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/tamano-de-busto-69" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Tamaño de busto
	</a>
			<ul>
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/busto-pequeno-82" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Busto Pequeño
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/busto-mediano-83" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Busto mediano
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/busto-grande-84" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Busto grande
	</a>
	</li>

									</ul>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/materiales-70" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Materiales
	</a>
			<ul>
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/algodon-85" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Algodón
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/microfibra-86" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Microfibra
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/encaje-87" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Encaje
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/blanda-88" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Blanda
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/tul-89" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Tul
	</a>
	</li>

									</ul>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/beneficios-71" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Beneficios
	</a>
			<ul>
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/corrector-de-postura-90" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Corrector de postura
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/realce-alto-91" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Realce alto
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/realce-medio-92" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Realce medio
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/realce-natural-93" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Realce natural
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/sin-realce-94" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Sin realce
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/control-y-reduccion-95" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Control y reducción
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/control-sisa-96" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Control sisa
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/control-contorno-97" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Control contorno
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/copa-profunda-98" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Copa profunda
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/push-up-aumentax-99" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Push up - aumentax
	</a>
	</li>

									</ul>
	</li>

									</ul>
	</li>

									</ul>
	</div>
</div>
<!-- /Block categories module -->
<?php }} ?>
