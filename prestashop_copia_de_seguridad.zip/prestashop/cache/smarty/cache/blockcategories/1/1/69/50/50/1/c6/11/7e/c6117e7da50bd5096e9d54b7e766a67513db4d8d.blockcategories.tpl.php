<?php /*%%SmartyHeaderCode:1671210119615e187011e9a2-10346336%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c6117e7da50bd5096e9d54b7e766a67513db4d8d' => 
    array (
      0 => 'C:\\laragon\\www\\prestashop_1.6.1.24\\prestashop\\themes\\transformer\\modules\\blockcategories\\blockcategories.tpl',
      1 => 1633442184,
      2 => 'file',
    ),
    '5843feb684a222e6ac464c656ac9071f5285865d' => 
    array (
      0 => 'C:\\laragon\\www\\prestashop_1.6.1.24\\prestashop\\themes\\transformer\\modules\\blockcategories\\category-tree-branch.tpl',
      1 => 1633442184,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1671210119615e187011e9a2-10346336',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_615e18bf0e3b63_93406228',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_615e18bf0e3b63_93406228')) {function content_615e18bf0e3b63_93406228($_smarty_tpl) {?><!-- Block categories module -->
<div id="categories_block_left" class="block">
	<h2 class="title_block">
					Buscar por
			</h2>
	<div class="block_content categories_tree_block">
		<ul class="tree dhtml">
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/ver-todos-51" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Ver todos
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/los-mas-vendidos-52" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Los más vendidos
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/nuevos-panties-53" title="">
		<span>&raquo;&nbsp;&nbsp;</span>Nuevos panties
	</a>
	</li>

									</ul>
	</div>
</div>
<!-- /Block categories module -->
<?php }} ?>
