<?php /*%%SmartyHeaderCode:1671210119615e187011e9a2-10346336%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c6117e7da50bd5096e9d54b7e766a67513db4d8d' => 
    array (
      0 => 'C:\\laragon\\www\\prestashop_1.6.1.24\\prestashop\\themes\\transformer\\modules\\blockcategories\\blockcategories.tpl',
      1 => 1633442184,
      2 => 'file',
    ),
    '5843feb684a222e6ac464c656ac9071f5285865d' => 
    array (
      0 => 'C:\\laragon\\www\\prestashop_1.6.1.24\\prestashop\\themes\\transformer\\modules\\blockcategories\\category-tree-branch.tpl',
      1 => 1633442184,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1671210119615e187011e9a2-10346336',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_615e18cf3b7676_82781770',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_615e18cf3b7676_82781770')) {function content_615e18cf3b7676_82781770($_smarty_tpl) {?><!-- Block categories module -->
<div id="categories_block_left" class="block">
	<h2 class="title_block">
					Vestidos
			</h2>
	<div class="block_content categories_tree_block">
		<ul class="tree dhtml">
												
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/vestidos-informales-9" title="¿Estás buscando un vestido para todos los días? Échale un vistazo a 
 nuestra selección para encontrar el vestido perfecto.">
		<span>&raquo;&nbsp;&nbsp;</span>Vestidos informales
	</a>
	</li>

																
<li >
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/vestidos-noche-10" title="¡Descubre nuestra colección y encuentra el vestido perfecto para una velada inolvidable!">
		<span>&raquo;&nbsp;&nbsp;</span>Vestidos de noche
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://prestashop_1.6.1.24.test/prestashop/vestidos-verano-11" title="Cortos, largos, de seda, estampados... aquí encontrarás el vestido perfecto para el verano.">
		<span>&raquo;&nbsp;&nbsp;</span>Vestidos de verano
	</a>
	</li>

									</ul>
	</div>
</div>
<!-- /Block categories module -->
<?php }} ?>
