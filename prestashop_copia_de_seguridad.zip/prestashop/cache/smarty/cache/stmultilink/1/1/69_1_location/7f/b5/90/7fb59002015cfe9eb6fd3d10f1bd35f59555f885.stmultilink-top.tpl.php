<?php /*%%SmartyHeaderCode:2125012452615e1873c04c66-11862054%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7fb59002015cfe9eb6fd3d10f1bd35f59555f885' => 
    array (
      0 => 'C:\\laragon\\www\\prestashop_1.6.1.24\\prestashop\\modules\\stmultilink\\views\\templates\\hook\\stmultilink-top.tpl',
      1 => 1633442188,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2125012452615e1873c04c66-11862054',
  'variables' => 
  array (
    'link_groups' => 0,
    'link_group' => 0,
    'link' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_615e1873c39897_98108508',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_615e1873c39897_98108508')) {function content_615e1873c39897_98108508($_smarty_tpl) {?>
<!-- Block stlinkgroups top module -->
    <dl id="multilink_1" class="stlinkgroups_top pull-right dropdown_wrap first-item  hide_on_mobile  top_bar_item">
        <dt class="dropdown_tri">
                    <div class="dropdown_tri_inner">
                M&aacute;s informaci&oacute;n
        <b></b>                    </div>
                </dt>
        <dd class="dropdown_list dropdown_right">
        <ul class="">
        					<li>
        		<a href="http://prestashop_1.6.1.24.test/prestashop/mi-cuenta" title="Manage my customer account"  >
                    My account
        		</a>
			</li>
					<li>
        		<a href="http://prestashop_1.6.1.24.test/prestashop/datos-personales" title="Manage my personal information"  >
                    My personal info
        		</a>
			</li>
						</ul>
        </dd>
    </dl>
<!-- /Block stlinkgroups top module --><?php }} ?>
