<?php /*%%SmartyHeaderCode:530635973615e187174e6e2-92142341%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd07642d25cc05c76e0edbb79cf18e578adc81ee8' => 
    array (
      0 => 'C:\\laragon\\www\\prestashop_1.6.1.24\\prestashop\\modules\\stmultilink\\views\\templates\\hook\\stmultilink-mobile.tpl',
      1 => 1633442188,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '530635973615e187174e6e2-92142341',
  'variables' => 
  array (
    'link_groups' => 0,
    'link_group' => 0,
    'link' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_615e1871777096_52565335',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_615e1871777096_52565335')) {function content_615e1871777096_52565335($_smarty_tpl) {?>
<!-- Block stlinkgroups top module -->
<!-- /Block stlinkgroups top module --><?php }} ?>
