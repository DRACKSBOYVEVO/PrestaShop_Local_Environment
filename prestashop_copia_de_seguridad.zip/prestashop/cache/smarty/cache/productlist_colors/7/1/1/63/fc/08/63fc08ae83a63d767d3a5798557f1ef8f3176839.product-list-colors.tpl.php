<?php /*%%SmartyHeaderCode:1836577507615e18723b05b9-72114428%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '63fc08ae83a63d767d3a5798557f1ef8f3176839' => 
    array (
      0 => 'C:\\laragon\\www\\prestashop_1.6.1.24\\prestashop\\themes\\transformer\\product-list-colors.tpl',
      1 => 1633442184,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1836577507615e18723b05b9-72114428',
  'variables' => 
  array (
    'colors_list' => 0,
    'col_img_dir' => 0,
    'color' => 0,
    'link' => 0,
    'img_color_exists' => 0,
    'img_col_dir' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_615e18723eff16_31019453',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_615e18723eff16_31019453')) {function content_615e18723eff16_31019453($_smarty_tpl) {?><ul class="color_to_pick_list">
							<li>
			<a href="http://prestashop_1.6.1.24.test/prestashop/pijamas/7-vestido-estampado-gasa.html#/1-size-s/15-color-verde" id="color_37" class="color_pick" style="background:#A0D468;">
							</a>
		</li>
									<li>
			<a href="http://prestashop_1.6.1.24.test/prestashop/pijamas/7-vestido-estampado-gasa.html#/2-size-m/16-color-amarillo" id="color_35" class="color_pick" style="background:#F1C40F;">
							</a>
		</li>
			</ul>
<?php }} ?>
