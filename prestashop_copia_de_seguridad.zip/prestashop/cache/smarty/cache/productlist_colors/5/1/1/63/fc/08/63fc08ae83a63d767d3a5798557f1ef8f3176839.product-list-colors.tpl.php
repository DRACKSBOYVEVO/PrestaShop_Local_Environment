<?php /*%%SmartyHeaderCode:1836577507615e18723b05b9-72114428%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '63fc08ae83a63d767d3a5798557f1ef8f3176839' => 
    array (
      0 => 'C:\\laragon\\www\\prestashop_1.6.1.24\\prestashop\\themes\\transformer\\product-list-colors.tpl',
      1 => 1633442184,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1836577507615e18723b05b9-72114428',
  'cache_lifetime' => 31536000,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_615e18cfbffb47_80499409',
  'has_nocache_code' => false,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_615e18cfbffb47_80499409')) {function content_615e18cfbffb47_80499409($_smarty_tpl) {?><?php }} ?>
