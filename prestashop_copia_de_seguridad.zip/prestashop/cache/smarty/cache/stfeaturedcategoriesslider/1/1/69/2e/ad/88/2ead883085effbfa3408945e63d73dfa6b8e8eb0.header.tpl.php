<?php /*%%SmartyHeaderCode:1992917947615e186ed4cf81-63143250%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2ead883085effbfa3408945e63d73dfa6b8e8eb0' => 
    array (
      0 => 'C:\\laragon\\www\\prestashop_1.6.1.24\\prestashop\\modules\\stfeaturedcategoriesslider\\views\\templates\\hook\\header.tpl',
      1 => 1633442187,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1992917947615e186ed4cf81-63143250',
  'variables' => 
  array (
    'custom_css' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_615e186ed63992_86323364',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_615e186ed63992_86323364')) {function content_615e186ed63992_86323364($_smarty_tpl) {?><?php }} ?>
