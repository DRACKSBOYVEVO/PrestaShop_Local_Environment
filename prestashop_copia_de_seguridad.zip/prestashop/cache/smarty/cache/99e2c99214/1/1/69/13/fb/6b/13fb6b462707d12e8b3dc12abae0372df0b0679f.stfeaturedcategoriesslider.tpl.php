<?php /*%%SmartyHeaderCode:162808996615ef6ffe5e6e2-97896509%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '13fb6b462707d12e8b3dc12abae0372df0b0679f' => 
    array (
      0 => 'C:\\laragon\\www\\prestashop_1.6.1.24\\prestashop\\modules\\stfeaturedcategoriesslider\\views\\templates\\hook\\stfeaturedcategoriesslider.tpl',
      1 => 1633442187,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '162808996615ef6ffe5e6e2-97896509',
  'variables' => 
  array (
    'aw_display' => 0,
    'fc_slider' => 0,
    'hook_hash' => 0,
    'hide_mob' => 0,
    'homeverybottom' => 0,
    'display_as_grid' => 0,
    'direction_nav' => 0,
    'category' => 0,
    'link' => 0,
    'homeSize' => 0,
    'img_cat_dir' => 0,
    'lang_iso' => 0,
    'slider_easing' => 0,
    'slider_slideshow' => 0,
    'slider_s_speed' => 0,
    'slider_a_speed' => 0,
    'slider_pause_on_hover' => 0,
    'slider_loop' => 0,
    'pro_per_lg' => 0,
    'pro_per_md' => 0,
    'pro_per_sm' => 0,
    'pro_per_xs' => 0,
    'pro_per_xxs' => 0,
    'slider_move' => 0,
    'mediumSize' => 0,
    'has_background_img' => 0,
    'speed' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_615ef7000383e8_89997858',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_615ef7000383e8_89997858')) {function content_615ef7000383e8_89997858($_smarty_tpl) {?><!-- Featured categories -->
<!--/ Featured categories --><?php }} ?>
