<?php /*%%SmartyHeaderCode:1013684403615e186e9e50c7-16986454%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7990d03afe311da46f7a4abe58eafc94108333ff' => 
    array (
      0 => 'C:\\laragon\\www\\prestashop_1.6.1.24\\prestashop\\modules\\stowlcarousel\\views\\templates\\hook\\header.tpl',
      1 => 1633442188,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1013684403615e186e9e50c7-16986454',
  'variables' => 
  array (
    'custom_css' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_615e186e9faec4_18088410',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_615e186e9faec4_18088410')) {function content_615e186e9faec4_18088410($_smarty_tpl) {?><?php }} ?>
