<?php /* Smarty version Smarty-3.1.19, created on 2021-10-06 16:43:10
         compiled from "C:\laragon\www\prestashop_1.6.1.24\prestashop\modules\stadvancedmenu\views\templates\hook\header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:830816456615e186ebbc4a1-93052668%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c1e61365147dd35eff1a305a9b52a674d25ad2bd' => 
    array (
      0 => 'C:\\laragon\\www\\prestashop_1.6.1.24\\prestashop\\modules\\stadvancedmenu\\views\\templates\\hook\\header.tpl',
      1 => 1633442185,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '830816456615e186ebbc4a1-93052668',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'advancedmenu_custom_css' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_615e186ebbe913_09000253',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_615e186ebbe913_09000253')) {function content_615e186ebbe913_09000253($_smarty_tpl) {?>
<?php if (isset($_smarty_tpl->tpl_vars['advancedmenu_custom_css']->value)&&$_smarty_tpl->tpl_vars['advancedmenu_custom_css']->value) {?>
<style type="text/css">
<?php echo $_smarty_tpl->tpl_vars['advancedmenu_custom_css']->value;?>

</style>
<?php }?>
<?php }} ?>
