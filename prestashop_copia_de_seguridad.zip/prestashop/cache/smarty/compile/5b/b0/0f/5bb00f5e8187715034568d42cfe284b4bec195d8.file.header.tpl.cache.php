<?php /* Smarty version Smarty-3.1.19, created on 2021-10-06 16:43:10
         compiled from "C:\laragon\www\prestashop_1.6.1.24\prestashop\modules\steasycontent\views\templates\hook\header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:911997854615e186e35e6a7-18695993%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5bb00f5e8187715034568d42cfe284b4bec195d8' => 
    array (
      0 => 'C:\\laragon\\www\\prestashop_1.6.1.24\\prestashop\\modules\\steasycontent\\views\\templates\\hook\\header.tpl',
      1 => 1633442187,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '911997854615e186e35e6a7-18695993',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'custom_css' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_615e186e361496_08852153',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_615e186e361496_08852153')) {function content_615e186e361496_08852153($_smarty_tpl) {?>
<?php if (isset($_smarty_tpl->tpl_vars['custom_css']->value)&&$_smarty_tpl->tpl_vars['custom_css']->value) {?>
<style type="text/css"><?php echo $_smarty_tpl->tpl_vars['custom_css']->value;?>
</style>
<?php }?><?php }} ?>
