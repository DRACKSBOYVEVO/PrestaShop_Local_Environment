<?php /* Smarty version Smarty-3.1.19, created on 2021-10-06 16:43:10
         compiled from "C:\laragon\www\prestashop_1.6.1.24\prestashop\modules\stfeaturedcategoriesslider\views\templates\hook\header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1992917947615e186ed4cf81-63143250%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2ead883085effbfa3408945e63d73dfa6b8e8eb0' => 
    array (
      0 => 'C:\\laragon\\www\\prestashop_1.6.1.24\\prestashop\\modules\\stfeaturedcategoriesslider\\views\\templates\\hook\\header.tpl',
      1 => 1633442187,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1992917947615e186ed4cf81-63143250',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'custom_css' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_615e186ed4f088_13577648',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_615e186ed4f088_13577648')) {function content_615e186ed4f088_13577648($_smarty_tpl) {?>
<?php if (isset($_smarty_tpl->tpl_vars['custom_css']->value)&&$_smarty_tpl->tpl_vars['custom_css']->value) {?>
<style type="text/css"><?php echo $_smarty_tpl->tpl_vars['custom_css']->value;?>
</style>
<?php }?><?php }} ?>
