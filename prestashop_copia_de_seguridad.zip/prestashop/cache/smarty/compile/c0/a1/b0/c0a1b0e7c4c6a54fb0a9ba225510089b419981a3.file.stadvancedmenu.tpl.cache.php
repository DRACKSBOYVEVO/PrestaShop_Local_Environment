<?php /* Smarty version Smarty-3.1.19, created on 2021-10-06 16:43:12
         compiled from "C:\laragon\www\prestashop_1.6.1.24\prestashop\modules\stadvancedmenu\views\templates\hook\stadvancedmenu.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1581768155615e1870dca899-70186130%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c0a1b0e7c4c6a54fb0a9ba225510089b419981a3' => 
    array (
      0 => 'C:\\laragon\\www\\prestashop_1.6.1.24\\prestashop\\modules\\stadvancedmenu\\views\\templates\\hook\\stadvancedmenu.tpl',
      1 => 1633442186,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1581768155615e1870dca899-70186130',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'stmenu' => 0,
    'header_bottom' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_615e1870dcf362_84444974',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_615e1870dcf362_84444974')) {function content_615e1870dcf362_84444974($_smarty_tpl) {?>
<?php if (isset($_smarty_tpl->tpl_vars['stmenu']->value)&&is_array($_smarty_tpl->tpl_vars['stmenu']->value)&&count($_smarty_tpl->tpl_vars['stmenu']->value)) {?>
<!-- Menu -->
<?php if (isset($_smarty_tpl->tpl_vars['header_bottom']->value)&&$_smarty_tpl->tpl_vars['header_bottom']->value) {?>
<div id="st_advanced_menu_container" class="animated fast">
	<div class="container">
<?php }?>
		<nav id="st_advanced_menu_wrap" role="navigation">
	    	<?php echo $_smarty_tpl->getSubTemplate ("./stadvancedmenu-ul.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>

		</nav>
<?php if (isset($_smarty_tpl->tpl_vars['header_bottom']->value)&&$_smarty_tpl->tpl_vars['header_bottom']->value) {?>
	</div>
</div>
<?php }?>
<!--/ Menu -->
<?php }?><?php }} ?>
